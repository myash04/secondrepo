package creatorone_package;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class main {
	
	
	public static void queueprovider(String queuestring, String site, String trans) {
		main n = new main();
		if(queuestring.contains("\r\n"))
		{
			String[] lines = queuestring.split("\r\n");
			
			for (int i = 1; i < lines.length; i++) {
				n.flowcreator(lines[i], site, trans);
			}
		}
		else
		{
			n.flowcreator(queuestring, site, trans);
		}
		
		
	}
	public String flowcreator (String quename, String site, String trans)
	{
		
		String queueName = quename;
		String site1 = site;
		String trans1 = trans;
		String method = trans1+"_"+site1;
		try {
	    String repmsgflowfileContent = new String(Files.readAllBytes(Paths.get("D:\\datapath\\UAT\\"+trans+"\\"+method+"\\"+method+"_REPLICATE.msgflow")));
	    String delmsgflowfileContent = new String(Files.readAllBytes(Paths.get("D:\\datapath\\UAT\\"+trans+"\\"+method+"\\"+method+"_REMOVE.msgflow")));
	    String repesqlfileContent = new String(Files.readAllBytes(Paths.get("D:\\datapath\\UAT\\"+trans+"\\"+method+"\\"+method+"_REPLICATION_Compute.esql"))); 
	    String delesqlfileContent = new String(Files.readAllBytes(Paths.get("D:\\datapath\\UAT\\"+trans+"\\"+method+"\\"+method+"_REMOVE_Compute.esql"))); 
	    String projectfileContent = new String(Files.readAllBytes(Paths.get("D:\\datapath\\UAT\\"+trans+"\\"+method+"\\.project"))); 
	    String appdescfileContent = new String(Files.readAllBytes(Paths.get("D:\\datapath\\UAT\\"+trans+"\\"+method+"\\application.descriptor"))); 
	    String editedrepmsgflowfileContent = repmsgflowfileContent.replace("abcdefghijk",queueName);
	    String editeddelmsgflowfileContent = delmsgflowfileContent.replace("abcdefghijk",queueName);
	    String editedprojectfileContent = projectfileContent.replace("abcdefghijk",queueName);
	    String  repflowname, foldername, filepath,delflowname,repesql,delesql,projectfilesString,applicationfileString;
	    repflowname = queueName+"_"+method+"_REPLICATE.msgflow";
	    delflowname = queueName+"_"+method+"_REMOVE.msgflow";
	    repesql = method+"_REPLICATION_Compute.esql";
	    delesql = method+"_REMOVE_Compute.esql";
	    projectfilesString=".project";
	    applicationfileString = "application.descriptor";
	    foldername = queueName+"_"+method+"_UAT";
	    filepath = "D:\\NEW\\"+foldername;
	    File file = new File("D:\\NEW\\"+foldername);
	    file.mkdir();
	    FileWriter repmsgflow = new FileWriter(filepath+"\\"+repflowname);
	    FileWriter delmsgflow = new FileWriter(filepath+"\\"+delflowname);
	    FileWriter repcompute = new FileWriter(filepath+"\\"+repesql);
	    FileWriter delcompute = new FileWriter(filepath+"\\"+delesql);
	    FileWriter projectfile = new FileWriter(filepath+"\\"+projectfilesString);
	    FileWriter applicationfile = new FileWriter(filepath+"\\"+applicationfileString);
	    repmsgflow.write(editedrepmsgflowfileContent);
	    repmsgflow.close();
	    delmsgflow.write(editeddelmsgflowfileContent);
	    delmsgflow.close();
	    repcompute.write(repesqlfileContent);
	    repcompute.close();
	    delcompute.write(delesqlfileContent);
	    delcompute.close();
	    projectfile.write(editedprojectfileContent);
	    projectfile.close();
	      applicationfile.write(appdescfileContent);
	      applicationfile.close();
	      System.out.println("Successfully wrote to the file.");
	    } catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
    }
		return "success";
		
		
	}

}
